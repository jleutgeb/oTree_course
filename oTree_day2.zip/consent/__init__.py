from otree.api import *


doc = """
this is my standard consent app
"""


class C(BaseConstants):
    NAME_IN_URL = 'consent'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    consent = models.BooleanField(
        label='Do you consent?',
        choices=[
            [True, 'Yes, I consent.'],
            ],
    ) # this variable records if the subject gave informed consent


# PAGES
class ConsentPage(Page):
    form_model = 'player'
    form_fields = ['consent']


class ResultsWaitPage(WaitPage):
    pass


class Results(Page):
    pass


page_sequence = [ConsentPage]
