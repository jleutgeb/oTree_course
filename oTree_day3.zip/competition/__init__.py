from otree.api import *


doc = """
Your app description
"""


class C(BaseConstants):
    NAME_IN_URL = 'competition'
    PLAYERS_PER_GROUP = 3
    NUM_ROUNDS = 2


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    offer = models.CurrencyField(
        label="Which price do you want to offer?",
        min = cu(0),
        max = cu(10)
    )

    buy_from = models.IntegerField(
        label="Who do you want to buy from?",
        widget=widgets.RadioSelect(),
        choices=[
            [1, "Player 1"],
            [2, "Player 2"]
        ]
    )
    
    game_role = models.StringField()

# PAGES
class Offer(Page):
    @staticmethod
    def is_displayed(player: Player):
        return player.game_role == 'seller'
    
    form_model='player'
    form_fields=['offer']


class DecisionWaitPage(WaitPage):
    pass


class Decision(Page):
    @staticmethod
    def is_displayed(player: Player):
        return player.game_role == 'buyer'
    
    form_model='player'
    form_fields = ['buy_from']

    @staticmethod
    def vars_for_template(player: Player):
        sellers = player.get_others_in_group()
        offers = [s.offer for s in sellers]
        seller_ids = [s.id_in_group for s in sellers]
        all_offers = list(zip(seller_ids, offers))
        return dict(
            sellers_offers = all_offers
        )


class ResultsWaitPage(WaitPage):
    @staticmethod
    def after_all_players_arrive(group: Group):
        buyer = group.get_player_by_id(C.PLAYERS_PER_GROUP)
        bought_from = buyer.buy_from
        seller = group.get_player_by_id(bought_from)
        price = seller.offer
        players = group.get_players()
        for p in players:
            if p.game_role == 'buyer':
                p.payoff = 10 - price
            elif p.game_role == 'seller' and p.id_in_group == bought_from:
                p.payoff = price
            else:
                p.payoff = 0


class Results(Page):
    @staticmethod
    def vars_for_template(player: Player):
        buyer = player.group.get_player_by_id(C.PLAYERS_PER_GROUP)
        bought_from = buyer.buy_from
        seller = player.group.get_player_by_id(bought_from)
        price = seller.offer
        seller_success = bought_from == player.id_in_group
        return dict(
            seller=bought_from,
            seller_success=seller_success,
            price=price,
        )


page_sequence = [Offer, DecisionWaitPage, Decision, ResultsWaitPage, Results]

# FUNCTIONS

def creating_session(subsession: Subsession):
    groups = subsession.get_groups()
    for g in groups:
        players = g.get_players()
        for p in players:
            if p.id_in_group == C.PLAYERS_PER_GROUP:
                p.game_role = 'buyer'
            else:
                p.game_role = 'seller'
