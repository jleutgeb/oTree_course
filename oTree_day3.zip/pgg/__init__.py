from otree.api import *
import random


doc = """
Your app description
"""


class C(BaseConstants):
    NAME_IN_URL = 'pgg'
    PLAYERS_PER_GROUP = 3
    NUM_ROUNDS = 2
    BUDGET = cu(10)
    # MULTIPLIER = 0.4


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    total = models.CurrencyField()
    multiplier = models.FloatField()


class Player(BasePlayer):
    contribution = models.CurrencyField(
        label='How much do you want to put into the group account?',
        min=0,
        max=C.BUDGET
    )
    treatment = models.StringField()


# PAGES
class MyPage(Page):
    pass


class ResultsWaitPage(WaitPage):
    pass


class Results(Page):
    pass


class Choice(Page):
    form_model = 'player'
    form_fields = ['contribution']


class ChoiceWaitPage(WaitPage):
    @staticmethod
    def after_all_players_arrive(group: Group):
        players = group.get_players()
        contributions = [p.contribution for p in players]
        group.total = sum(contributions)
        payout = group.total * group.multiplier
        for p in players:
            p.payoff = C.BUDGET - p.contribution + payout


class Feedback(Page):
    @staticmethod
    def vars_for_template(player: Player):
        others = player.get_others_in_group()
        others_contributions = [o.contribution for o in others]
        others_payoffs = [o.payoff for o in others]
        return dict(
            others_contributions=others_contributions,
            others_payoffs=others_payoffs
        )


class FinalFeedback(Page):
    @staticmethod
    def is_displayed(player: Player):
        last_round = player.round_number == C.NUM_ROUNDS
        return last_round


page_sequence = [Choice, ChoiceWaitPage, Feedback, FinalFeedback]

# FUNCTIONS 

def creating_session(subsession: Subsession):
    if subsession.session.config['shuffle_within_groups'] == True:
        matching = subsession.get_group_matrix()
        for group in matching:
            random.shuffle(group)
        subsession.set_group_matrix(matching)
        players = subsession.get_players()
        for player in players:
            player.treatment = 'shuffle within groups'
    elif subsession.session.config['matching_silos'] == True:
        matching = subsession.get_group_matrix()
        all_players = [player for group in matching for player in group]
        first_two_groups = all_players[:6]
        last_two_groups = all_players[6:]
        random.shuffle(first_two_groups)
        random.shuffle(last_two_groups)
        shuffled_matching = [first_two_groups[:3], first_two_groups[3:], last_two_groups[:3], last_two_groups[3:]]
        subsession.set_group_matrix(shuffled_matching)
        players = subsession.get_players()
        for player in players:
            player.treatment = 'matching silos'
    else:
        subsession.group_randomly()
        players = subsession.get_players()
        for player in players:
            player.treatment = 'baseline'
    
    groups = subsession.get_groups()
    for g in groups:
        g.multiplier = g.session.config['multiplier']
